﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CarApi.Models
{
    public class Car
    {

        public int ID { get; set; }

        public string Registration { get; set; }
        public string Vin { get; set; }
        public double Price { get; set; }
        public double Vat { get; set; }


    }
}